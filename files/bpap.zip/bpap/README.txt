Instructions on how to run the NEURON simulations
=================================================

1. Unpack the archive. A new directory called "bpap" should be
   created.

2. Compile all the ".mod" files in the "bpap" directory using
   the NEURON utility "nrnivmodl".

3. Use NEURON to run "bpap-interactive1.hoc". A number of windows
   should appear on the screen.

To produce the data behind Figure 1
===================================

Click on "BPAP Run" at the bottom of the "Control Panel". Figs 1B-E
are shown in the "Spine Variables" panel. Figs 1F-I are in the
"Features vs distance or size" window.

To produce the data behind Figure 2
===================================

Set "gmax_car_spine" to 0 and then click on "BPAP Run"

Figure 3
========

(A) An approximation of the "EPSP amplitude of a synapse measured at
the soma" as a function of distance is plotted in the bottom left
plot. A normalised version of this forms Fig 3A (see equation in
section 3.2). The approximation used is the transverse
impedance. To obtain the actual values used, click on "Find EPSP
amplitudes", but this is slow.

(B-E) To produce this data, reset gmax_car_spine to 170pS (or click on
the tick next to it). Click on "BPAP Run". Then click on "Size"
underneath where it says "Plot features vs.". This plots the features
versus size rather than attenuation, as shown in the text, so the
plots appear the other way around. You may need to extend the "Control
panel" downwards to see this text.

Figure 4
========

Click on "distance" under "Plot features vs". The window labelled
"Input impedance vs" now shows (A). 

Click on "size" under "Plot features vs". The window labelled "Input
impedance vs" now shows the data underlying (B).

Figure 5
========

Click on "distance" under "Plot features vs". Type 10 in the "Jitter (ms)"
box and click on "BPAP Run". This will show the data from one run of
the simulation, but is quite slow. To obtain Figure 5, the number of
runs needs to be set to 100, but this is very slow.

Figure 6
========

Set "Jitter" back to 0. Set "nsyn" (number of synapses) to 160.  Go to
"Tools->VariableTimeStep" in the "NEURON Main Menu" and set "Absolute
Tolerance" to 1e-07. Click on "BPAP run".


